from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from customers.customer import Customer

class Policy(ABC):
    """ class for insurance policies."""

    def __init__(self, base_premium: float):
        self.base_premium = base_premium

    @abstractmethod
    def calculate_premium(self, customer: 'Customer') -> float:
        pass

    def get_policy_details(self) -> dict:
        return {
            'base_premium': self.base_premium
        }

"""calculated and returned works"""