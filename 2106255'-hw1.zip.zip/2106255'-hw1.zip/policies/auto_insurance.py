from .policy import Policy
from customers.customer import Customer

class AutoInsurancePolicy(Policy):
    """ insurance vary based on age and driving record"""

    def __init__(self, base_premium: float, driving_record: str, vehicle_type: str):
        super().__init__(base_premium)
        self.driving_record = driving_record
        self.vehicle_type = vehicle_type

    def calculate_premium(self, customer: Customer) -> float:
        """to calculate the auto insurance premium."""
        premium = self.base_premium
        # Increase premium if driver is young
        if customer.age < 25:
            premium *= 1.2
        # Adjust premium based on driving record
        if self.driving_record == "poor":
            premium *= 1.5
        return premium
