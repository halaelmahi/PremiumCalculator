from .policy import Policy
from customers.customer import Customer

class LifeInsurancePolicy(Policy):
    """vary with age and coverage amount"""

    def __init__(self, base_premium: float, coverage_amount: float):
        super().__init__(base_premium)
        self.coverage_amount = coverage_amount

    def calculate_premium(self, customer: Customer) -> float:
        """calculate life insurance premium"""
        premium = self.base_premium + (self.coverage_amount * 0.0005)
        return premium
