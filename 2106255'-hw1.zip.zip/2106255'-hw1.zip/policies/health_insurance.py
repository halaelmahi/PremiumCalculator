from .policy import Policy
from typing import List
from customers.customer import Customer

class HealthInsurancePolicy(Policy):
    """the health insurance premiums will change with the age and certain medical conditions"""

    def __init__(self, base_premium: float, medical_conditions: List[str]):
        super().__init__(base_premium)
        self.medical_conditions = medical_conditions

    def calculate_premium(self, customer: Customer) -> float:
        """for calculating the health insurance premium"""
        premium = self.base_premium
        # Increase premium based on age
        if customer.age > 40:
            premium += (customer.age - 40) * 10
        # Increase premium if there are medical conditions
        if self.medical_conditions:
            premium *= 1.5
        return premium
