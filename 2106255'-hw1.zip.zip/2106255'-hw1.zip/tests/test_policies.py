import unittest
from policies.auto_insurance import AutoInsurancePolicy
from policies.life_insurance import LifeInsurancePolicy
from policies.health_insurance import HealthInsurancePolicy
from customers.customer import Customer

"""unitest this is where individual things are tested in 1by1 to make sure if they work as i expect"""
class TestPolicies(unittest.TestCase):

    def test_auto_insurance_young_driver(self):
        customer = Customer(customer_id=105, name='Dave Teen', age=20, address='123 Young St')
        auto_policy = AutoInsurancePolicy(base_premium=300.0, driving_record='good', vehicle_type='sedan')
        premium = auto_policy.calculate_premium(customer)
        expected_premium = 300.0 * 1.2  # Increase by 20% for age under 25
        self.assertAlmostEqual(premium, expected_premium)

    def test_life_insurance_high_coverage(self):
        customer = Customer(customer_id=106, name='Eve Rich', age=45, address='456 Wealth Ave')
        life_policy = LifeInsurancePolicy(base_premium=150.0, coverage_amount=1000000)
        premium = life_policy.calculate_premium(customer)
        expected_premium = 150.0 + (1000000 * 0.0005)
        self.assertAlmostEqual(premium, expected_premium)

    def test_health_insurance_senior_with_conditions(self):
        customer = Customer(customer_id=107, name='Frank Elder', age=70, address='789 Old Rd')
        health_policy = HealthInsurancePolicy(base_premium=200.0, medical_conditions=['arthritis'])
        premium = health_policy.calculate_premium(customer)
        age_increment = (70 - 40) * 10  # Additional $10 for each year over 40
        expected_premium = (200.0 + age_increment) * 1.5  # Increase by 50% for medical conditions
        self.assertAlmostEqual(premium, expected_premium)

if __name__ == '__main__':
    unittest.main()
