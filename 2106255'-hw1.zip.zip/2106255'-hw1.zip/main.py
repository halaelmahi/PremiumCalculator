from customers.customer import Customer
from policies.health_insurance import HealthInsurancePolicy
from policies.auto_insurance import AutoInsurancePolicy
from policies.life_insurance import LifeInsurancePolicy
from quotes.quote_generator import generate_quote

def main():
    """create a customer"""
    customer = Customer(customer_id=101, name='Hala Hussein Elmahi', age=22, address='123 Besiktas St')
    
    """Health Insurance Quote"""
    health_policy = HealthInsurancePolicy(base_premium=200.0, medical_conditions=[])
    generate_quote(customer, health_policy)

    """Auto Insurance Quote"""
    auto_policy = AutoInsurancePolicy(base_premium=300.0, driving_record='good', vehicle_type='sedan')
    generate_quote(customer, auto_policy)

    """life Insurance Quote"""
    life_policy = LifeInsurancePolicy(base_premium=150.0, coverage_amount=250000)
    generate_quote(customer, life_policy)

    customer.add_policy(health_policy)
    customer.add_policy(auto_policy)
    customer.add_policy(life_policy)

if __name__ == '__main__':
    main()
