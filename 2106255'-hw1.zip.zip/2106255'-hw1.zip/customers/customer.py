from typing import List
from policies.policy import Policy

class Customer:
    """represents the customer"""

    def __init__(self, customer_id: int, name: str, age: int, address: str):
        self.customer_id = customer_id
        self.name = name
        self.age = age
        self.address = address
        self.past_policies: List[Policy] = []

    def add_policy(self, policy: Policy) -> None:
        """retreive to the customer's history"""
        self.past_policies.append(policy)

    def get_info(self) -> dict:
        """get customer information"""
        return {
            'customer_id': self.customer_id,
            'name': self.name,
            'age': self.age,
            'address': self.address
        }

"""not reason for error"""