from policies.policy import Policy
from customers.customer import Customer

class PremiumCalculator:
    """calculate premiums"""

    @staticmethod
    def calculate(policy: Policy, customer: Customer) -> float:
        """calculate the premium using the policy method"""
        return policy.calculate_premium(customer)
