from policies.policy import Policy
from customers.customer import Customer
from calculators.premium_calculator import PremiumCalculator

def generate_quote(customer: Customer, policy: Policy) -> None:
    """make and show the premium quote"""
    premium = PremiumCalculator.calculate(policy, customer)
    print(f"Customer: {customer.name}")
    print(f"Policy Type: {policy.__class__.__name__}")
    print(f"Estimated Premium: ${premium:.2f}\n")
